# ExtendoAFC — Arsenal Highlights App

A mobile-friendly web app showing Arsenal match highlights and player reel data from Wix CMS.

## Structure

```
index.html                  ← The app frontend
netlify.toml                ← Routes /api/* to Netlify functions
netlify/functions/
  wix-data.js               ← Server-side Wix CMS proxy
```

## Deploy to Netlify

1. Push this repo to GitHub
2. Go to app.netlify.com → "Add new site" → "Import an existing project"
3. Connect your GitHub repo
4. Add environment variable: `WIX_API_KEY` = your Wix API key
5. Deploy — Netlify will detect the function automatically
